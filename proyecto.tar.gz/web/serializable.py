#transformarlos objetos y dar propiedad para quesepuedan reprwesentar en otros formatos
from clases.models import Materia, Alumno

from rest_framework import serializers 

class MateriaSerializable(serializers.ModelSerializer):
	class Meta:
		model=Materia
		fields=('id','nombre','capacidad','cupos_disponibles')
		
class AlumnoSerializable(serializers.ModelSerializer):
	class Meta:
		model=Alumno
		fields=('cedula','nombre','Apellido')

