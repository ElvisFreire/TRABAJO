from clases.models import Materia, Alumno
from rest_framework import viewsets
from .serializable import MateriaSerializable, AlumnoSerializable


class MateriaViewSet(viewsets.ModelViewSet):
	serializer_class=MateriaSerializable
	queryset=Materia.objects.filter(capacidad__lte= 29)

class AlumnoViewSet(viewsets.ModelViewSet):
	serializer_class=AlumnoSerializable
	queryset=Alumno.objects.all()


	