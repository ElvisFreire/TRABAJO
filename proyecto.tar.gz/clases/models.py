from __future__ import unicode_literals
from django.db import models

class Alumno(models.Model):
	nombre=models.CharField(max_length=30)
	Apellido=models.CharField(max_length=30)
	cedula=models.CharField(primary_key=True, max_length=10, unique=True)

	def __str__(self):
		return self.cedula


class Materia(models.Model):
	nombre=models.CharField(max_length=30)
	capacidad=models.IntegerField()
	cupos_disponibles=models.IntegerField(blank=True,null=True)
	def __str__(self):
		return self.nombre
		