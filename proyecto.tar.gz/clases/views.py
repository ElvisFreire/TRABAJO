from django.shortcuts import render,redirect
from clases.models import Materia, Alumno
from clases.forms import FormularioAlumno, FormularioMateria
 
# Create your views here.
def matriculas(request):
	m=Materia.objects.all()
	a=Alumno.objects.all()
	context={
		'm':m,
		'a':a,
	}
	return render(request,"matriculas.html",context)

def creaClase(request):
	fmate=FormularioMateria(request.POST or None)
	context={
		'fmate':fmate,
	}
	if fmate.is_valid():
		ma=Materia()
		f_data=fmate.cleaned_data
		ma.nombre=f_data.get("nombre")
		ma.capacidad=f_data.get("capacidad")
		ma.save()
		ma.cupos_disponibles=ma.capacidad
		ma.save()	

		return redirect(matriculas)

	return render(request,"creaClase.html",context)

def creaEstudiante(request):
	falu=FormularioAlumno(request.POST or None)
	context={
		'falu':falu,
	}
	if falu.is_valid():
		a=Alumno()
		f_data=falu.cleaned_data
		a.nombre=f_data.get("nombre")
		a.Apellido=f_data.get("Apellido")
		a.cedula=f_data.get("cedula")	
		a.save()

		return redirect(matriculas)

	return render(request,"creaEstudiante.html",context)

def eliminarMa(request):
	ma=Materia.objects.get(id=request.GET["id"])	
	ma.delete()
	return redirect(matriculas)
def eliminarEs(request):
	a=Alumno.objects.get(cedula=request.GET["cedula"])	
	a.delete()
	return redirect(matriculas)