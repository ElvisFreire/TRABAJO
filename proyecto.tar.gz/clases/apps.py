from django.apps import AppConfig


class ClasesConfig(AppConfig):
    name = 'clases'
