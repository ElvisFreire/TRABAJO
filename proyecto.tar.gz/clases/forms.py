from django import forms
from .models import Materia, Alumno

class FormularioMateria(forms.ModelForm):	
	class Meta:
		model=Materia
		fields=["nombre","capacidad"]
		
class FormularioAlumno(forms.ModelForm):
	class Meta:
		model=Alumno
		fields=["nombre","Apellido","cedula"]