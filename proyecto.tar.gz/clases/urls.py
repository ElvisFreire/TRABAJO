from django.conf.urls import  url
from django.contrib import admin

urlpatterns = [

    url(r'^$', 'clases.views.matriculas'),
    url(r'^crear/$', 'clases.views.creaClase'),
    url(r'^crearEstudiante/$', 'clases.views.creaEstudiante'),
    url(r'^eliminarMa/$', 'clases.views.eliminarMa'),
    url(r'^eliminarEs/$', 'clases.views.eliminarEs')
    
]